package com.jhgzin.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.*
import com.jhgzin.jarvis.ai.*
import com.jhgzin.jarvis.data.*
import com.jhgzin.jarvis.reminders.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFF050A10)
private val Panel = Color(0xFF0C1722)
private val Cyan = Color(0xFF48DFFF)
private val Muted = Color(0xFF9AB2C4)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); tts = TextToSpeech(this, this); setContent { JarvisApp(::speak, ::stopSpeaking) } }
    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS; if (ttsReady) tts?.language = Locale("pt", "BR") }
    private fun speak(text: String) { if (ttsReady && getSharedPreferences("jarvis_settings", MODE_PRIVATE).getBoolean("speech_enabled", true)) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response") }
    private fun stopSpeaking() { tts?.stop() }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable private fun JarvisApp(speak: (String) -> Unit, stopSpeaking: () -> Unit) {
    val context = LocalContext.current
    val db = remember { AppDatabase.get(context) }
    val nav = rememberNavController()
    val destinations = listOf("Início", "Conversa", "Tarefas", "Memória", "Configurações")
    val icons = listOf(Icons.Default.Home, Icons.Default.Chat, Icons.Default.CheckCircle, Icons.Default.Psychology, Icons.Default.Settings)
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onPrimary = Bg, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = { NavigationBar(containerColor = Panel) {
            destinations.forEachIndexed { i, label -> NavigationBarItem(selected = false, onClick = { nav.navigate(listOf("home","chat","tasks","memory","settings")[i]) { launchSingleTop = true } }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) }) }
        } }) { padding ->
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") { HomeScreen(onChat = { nav.navigate("chat") }, onTasks = { nav.navigate("tasks") }, onSettings = { nav.navigate("settings") }, db = db) }
                composable("chat") { ChatScreen(db, speak, stopSpeaking) }
                composable("tasks") { TasksScreen(db) }
                composable("memory") { MemoryScreen(db) }
                composable("settings") { SettingsScreen() }
            }
        }
    }
}

@Composable private fun HomeScreen(onChat: () -> Unit, onTasks: () -> Unit, onSettings: () -> Unit, db: AppDatabase) {
    val tasks by db.taskDao().observeAll().collectAsState(initial = emptyList())
    val context = LocalContext.current
    val backendConfigured = remember { !context.getSharedPreferences("jarvis_settings", 0).getString("backend_url", "").isNullOrBlank() }
    val infinite = rememberInfiniteTransition(label = "core")
    val pulse by infinite.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "pulse")
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when (hour) { in 5..11 -> "Bom dia"; in 12..17 -> "Boa tarde"; else -> "Boa noite" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("J.A.R.V.I.S.", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("PERSONAL INTELLIGENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp) }; IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Configurações", tint = Muted) } }
        Spacer(Modifier.height(28.dp)); Text("$greeting.", fontSize = 25.sp, fontWeight = FontWeight.Medium); Text("Estou pronto para ajudar.", color = Muted)
        Spacer(Modifier.height(30.dp))
        Box(Modifier.size(224.dp).scale(pulse).border(1.dp, Cyan.copy(alpha = .65f), CircleShape).padding(13.dp).border(1.dp, Cyan.copy(alpha = .35f), CircleShape).padding(12.dp).background(Brush.radialGradient(listOf(Color(0xFF123E55), Color(0xFF08111C), Bg)), CircleShape), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(58.dp)); Text("JARVIS", color = Cyan, letterSpacing = 4.sp, fontWeight = FontWeight.Light); Text("EM ESPERA", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp) }
        }
        Spacer(Modifier.height(26.dp)); Button(onClick = onChat, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("INICIAR CONVERSA", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(18.dp)); Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { SummaryCard("Tarefas pendentes", tasks.count { !it.completed }.toString(), Modifier.weight(1f), onTasks); SummaryCard("Conexão IA", if (backendConfigured) "Configurada" else "Não ligada", Modifier.weight(1f), onSettings) }
        Spacer(Modifier.height(16.dp)); Text("PRÓXIMAS TAREFAS", color = Cyan, fontSize = 12.sp, letterSpacing = 2.sp, modifier = Modifier.align(Alignment.Start))
        val pending = tasks.filter { !it.completed }.take(3)
        if (pending.isEmpty()) Text("Nenhuma tarefa pendente. Aproveite o tempo livre.", color = Muted, modifier = Modifier.padding(16.dp)) else pending.forEach { Text("• ${it.title}", color = Color.White, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) }
    }
}
@Composable private fun SummaryCard(title: String, value: String, modifier: Modifier, click: () -> Unit) { Card(modifier.clickable(onClick = click), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp)) { Text(title, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(8.dp)); Text(value, color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold) } } }

@Composable private fun ChatScreen(db: AppDatabase, speak: (String) -> Unit, stopSpeaking: () -> Unit) {
    val context = LocalContext.current
    val messages by db.chatDao().recent().collectAsState(initial = emptyList())
    var input by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }; var status by remember { mutableStateOf("Pronto") }; var error by remember { mutableStateOf("") }
    val provider = remember { BackendAiProvider(context) }
    val scope = rememberCoroutineScope()
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                val recognizer = SpeechRecognizer.createSpeechRecognizer(context); speechRecognizer = recognizer
                recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { status = "Ouvindo…" }
                    override fun onBeginningOfSpeech() { status = "Ouvindo…" }
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { status = "Processando fala…" }
                    override fun onError(errorCode: Int) { status = "Reconhecimento interrompido"; error = "Não consegui reconhecer a fala. Tente novamente ou digite sua mensagem." }
                    override fun onResults(results: Bundle?) { input = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); status = "Pronto" }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR").putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                recognizer.startListening(intent)
            } else error = "O reconhecimento de fala não está disponível neste dispositivo."
        } else error = "Permissão de microfone negada. Você ainda pode digitar."
    }
    DisposableEffect(Unit) { onDispose { speechRecognizer?.destroy() } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("CONVERSA", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(status, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg -> Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (msg.role == "user") Color(0xFF102A3A) else Panel)) { Column(Modifier.padding(12.dp)) { Text(if (msg.role == "user") "VOCÊ" else "J.A.R.V.I.S.", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(msg.content, color = Color.White) } } }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF9C9C), fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            IconButton(onClick = { permission.launch(Manifest.permission.RECORD_AUDIO) }, enabled = !busy) { Icon(Icons.Default.Mic, "Falar", tint = Cyan) }
            OutlinedTextField(input, { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Fale ou digite…") }, maxLines = 3)
            IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                val userText = input.trim(); input = ""; error = ""; busy = true; status = "Processando…"
                scope.launch {
                    db.chatDao().insert(ChatMessageEntity(role = "user", content = userText))
                    val contextMessages = messages.asReversed().map { it.role to it.content }
                    when (val result = provider.reply(userText, contextMessages)) {
                        is AiResult.Success -> { db.chatDao().insert(ChatMessageEntity(role = "assistant", content = result.text)); speak(result.text); status = "Respondido" }
                        is AiResult.Failure -> { error = result.message; db.chatDao().insert(ChatMessageEntity(role = "assistant", content = result.message)); status = "Atenção necessária" }
                    }
                    busy = false
                }
            }) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Cyan, strokeWidth = 2.dp) else Icon(Icons.Default.Send, "Enviar", tint = Cyan) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(onClick = stopSpeaking) { Icon(Icons.Default.Stop, null); Text("Parar voz") }; TextButton(onClick = { scope.launch { db.chatDao().clear() } }) { Text("Limpar histórico") } }
    }
}

@Composable private fun TasksScreen(db: AppDatabase) {
    val context = LocalContext.current; val tasks by db.taskDao().observeAll().collectAsState(initial = emptyList()); val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Pessoal") }; var priority by remember { mutableStateOf("Normal") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("TAREFAS", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Bold); Text("Armazenadas localmente neste aparelho", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp)); OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Título da tarefa") }, singleLine = true)
        OutlinedTextField(notes, { notes = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Observações (opcional)") }, maxLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { var expanded by remember { mutableStateOf(false) }; Box(Modifier.weight(1f)) { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category) }; DropdownMenu(expanded, { expanded = false }) { listOf("Pessoal","Trabalho","YouTube","Desenvolvimento de jogos","Estudos","Outros").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { category = it; expanded = false }) } } }; var pExpanded by remember { mutableStateOf(false) }; Box(Modifier.weight(1f)) { OutlinedButton(onClick = { pExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("Prioridade: $priority") }; DropdownMenu(pExpanded, { pExpanded = false }) { listOf("Baixa","Normal","Alta").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { priority = it; pExpanded = false }) } } } }
        Button(onClick = { if (title.isNotBlank()) { scope.launch { db.taskDao().insert(TaskEntity(title = title.trim(), notes = notes.trim(), category = category, priority = priority)) }; title = ""; notes = "" } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Adicionar tarefa") }
        Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(tasks, key = { it.id }) { task -> Card(colors = CardDefaults.cardColors(containerColor = Panel)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(task.completed, { checked -> scope.launch { db.taskDao().update(task.copy(completed = checked)) } }); Column(Modifier.weight(1f)) { Text(task.title, color = if (task.completed) Muted else Color.White, fontWeight = FontWeight.Medium); Text("${task.category} • ${task.priority}${if (task.notes.isNotBlank()) " • ${task.notes}" else ""}", color = Muted, fontSize = 11.sp) }; IconButton(onClick = { scope.launch { db.taskDao().delete(task) } }) { Icon(Icons.Default.Delete, "Excluir", tint = Color(0xFFFF7777)) } } } } }
    }
}

@Composable private fun MemoryScreen(db: AppDatabase) {
    val memories by db.memoryDao().observeAll().collectAsState(initial = emptyList()); val scope = rememberCoroutineScope(); var label by remember { mutableStateOf("") }; var value by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(18.dp)) { Text("MEMÓRIA PESSOAL", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Somente informações que você salvar aqui.", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(12.dp)); OutlinedTextField(label, { label = it }, Modifier.fillMaxWidth(), label = { Text("Nome / categoria") }, singleLine = true); OutlinedTextField(value, { value = it }, Modifier.fillMaxWidth(), label = { Text("Informação para lembrar") }); Button(onClick = { if (label.isNotBlank() && value.isNotBlank()) scope.launch { db.memoryDao().insert(MemoryEntity(label = label.trim(), value = value.trim())); label = ""; value = "" } }, enabled = label.isNotBlank() && value.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Salvar memória") }; Spacer(Modifier.height(12.dp)); LazyColumn { items(memories, key = { it.id }) { m -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(m.label, color = Cyan, fontWeight = FontWeight.Bold); Text(m.value) }; IconButton(onClick = { scope.launch { db.memoryDao().delete(m) } }) { Icon(Icons.Default.Delete, "Excluir memória", tint = Color(0xFFFF7777)) } } } } } }
}

@Composable private fun SettingsScreen() {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("jarvis_settings", 0) }; var backend by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }; var speech by remember { mutableStateOf(prefs.getBoolean("speech_enabled", true)) }; var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) { Text("CONFIGURAÇÕES", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(14.dp)); Text("INTELIGÊNCIA ARTIFICIAL", color = Cyan, fontSize = 12.sp, letterSpacing = 1.5.sp); Text("URL HTTPS do backend compatível", color = Muted, fontSize = 12.sp); OutlinedTextField(backend, { backend = it; saved = false }, Modifier.fillMaxWidth(), placeholder = { Text("https://seu-backend.example/api/chat") }, singleLine = true); Text("O backend deve receber JSON { messages: [{role, content}] } e devolver { reply: \"...\" }. Não cole chaves de API aqui.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Text("Respostas faladas", modifier = Modifier.weight(1f)); Switch(speech, { speech = it; prefs.edit().putBoolean("speech_enabled", it).apply() }) }; Button(onClick = { prefs.edit().putString("backend_url", backend.trim()).apply(); saved = true }, modifier = Modifier.fillMaxWidth()) { Text("Salvar configurações") }; if (saved) Text("Preferências salvas neste aparelho.", color = Cyan); Spacer(Modifier.height(20.dp)); Text("INTEGRAÇÕES", color = Cyan, fontSize = 12.sp, letterSpacing = 1.5.sp); Text("YouTube: OAuth e projeto Google Cloud ainda precisam ser configurados. Não há dados de canal conectados nesta versão.", color = Muted); Text("Ativação por palavra-chave em segundo plano não está habilitada. Use o botão de microfone dentro da conversa.", color = Muted, modifier = Modifier.padding(top = 8.dp)); Text("Privacidade: tarefas, memórias e histórico ficam no banco local. Mensagens enviadas à IA são transmitidas ao backend configurado.", color = Muted, modifier = Modifier.padding(top = 8.dp)) }
}
