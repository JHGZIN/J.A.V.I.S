package com.jhgzin.jarvis.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    fun schedule(context: Context, id: Long, atMillis: Long, title: String, body: String) {
        if (atMillis <= System.currentTimeMillis()) return
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", title).putExtra("body", body)
        val pending = PendingIntent.getBroadcast(context, id.toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pending)
        else alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pending)
    }
}
