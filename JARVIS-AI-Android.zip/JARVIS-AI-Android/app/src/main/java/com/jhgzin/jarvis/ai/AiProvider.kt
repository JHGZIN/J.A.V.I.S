package com.jhgzin.jarvis.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Failure(val message: String) : AiResult()
}
interface AiProvider { suspend fun reply(message: String, context: List<Pair<String, String>>): AiResult }

/** OpenAI-compatible backend proxy. Store only your own backend URL here; never embed provider API secrets in the APK. */
class BackendAiProvider(private val appContext: Context) : AiProvider {
    override suspend fun reply(message: String, context: List<Pair<String, String>>): AiResult = withContext(Dispatchers.IO) {
        val prefs = appContext.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)
        val endpoint = prefs.getString("backend_url", "")?.trim().orEmpty()
        if (endpoint.isBlank()) return@withContext AiResult.Failure("IA não configurada. Adicione a URL HTTPS do seu backend em Configurações → IA.")
        if (!endpoint.startsWith("https://")) return@withContext AiResult.Failure("Por segurança, o endereço do backend precisa usar HTTPS.")
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 12000; readTimeout = 30000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            val messages = JSONArray().put(JSONObject().put("role", "system").put("content", "Você é J.A.R.V.I.S. AI, assistente pessoal calmo e objetivo. Responda em português brasileiro. Não afirme que executou ações que não foram executadas. Dados pessoais só podem ser afirmados se vierem do contexto fornecido."))
            context.takeLast(12).forEach { (role, content) -> messages.put(JSONObject().put("role", role).put("content", content)) }
            messages.put(JSONObject().put("role", "user").put("content", message))
            val payload = JSONObject().put("messages", messages).toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) return@withContext AiResult.Failure("O backend respondeu com HTTP $code. Verifique a configuração e os limites do serviço.")
            val json = JSONObject(body)
            val text = json.optString("reply").ifBlank { json.optString("content") }
            if (text.isBlank()) AiResult.Failure("O backend respondeu, mas não retornou o campo 'reply' ou 'content'.") else AiResult.Success(text)
        } catch (_: java.net.SocketTimeoutException) { AiResult.Failure("A conexão demorou demais. Tente novamente.") }
          catch (_: Exception) { AiResult.Failure("Não consegui conectar ao backend. Verifique a internet e a URL configurada.") }
        finally { conn?.disconnect() }
    }
}
