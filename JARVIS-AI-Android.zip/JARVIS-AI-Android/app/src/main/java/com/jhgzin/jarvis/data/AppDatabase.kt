package com.jhgzin.jarvis.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY completed ASC, dueAtMillis ASC, createdAtMillis DESC") fun observeAll(): Flow<List<TaskEntity>>
    @Query("SELECT * FROM tasks WHERE completed = 0 ORDER BY dueAtMillis ASC") suspend fun pending(): List<TaskEntity>
    @Insert suspend fun insert(task: TaskEntity): Long
    @Update suspend fun update(task: TaskEntity)
    @Delete suspend fun delete(task: TaskEntity)
}
@Dao interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY createdAtMillis DESC") fun observeAll(): Flow<List<MemoryEntity>>
    @Insert suspend fun insert(memory: MemoryEntity): Long
    @Delete suspend fun delete(memory: MemoryEntity)
    @Query("DELETE FROM memories") suspend fun clear()
}
@Dao interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY createdAtMillis DESC LIMIT 100") fun recent(): Flow<List<ChatMessageEntity>>
    @Insert suspend fun insert(message: ChatMessageEntity): Long
    @Query("DELETE FROM chat_messages") suspend fun clear()
}
@Database(entities = [TaskEntity::class, MemoryEntity::class, ChatMessageEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun memoryDao(): MemoryDao
    abstract fun chatDao(): ChatDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "jarvis.db").build().also { INSTANCE = it }
        }
    }
}
