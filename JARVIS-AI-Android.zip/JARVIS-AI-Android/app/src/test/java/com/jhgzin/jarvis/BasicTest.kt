package com.jhgzin.jarvis

import org.junit.Assert.assertTrue
import org.junit.Test

class BasicTest {
    @Test fun appIdentityIsNotBlank() { assertTrue("J.A.R.V.I.S. AI".isNotBlank()) }
}
