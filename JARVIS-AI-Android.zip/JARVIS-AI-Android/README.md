# J.A.R.V.I.S. AI — Android Kotlin / Jetpack Compose

Projeto nativo de base para assistente pessoal em português brasileiro. Inclui interface Compose, navegação, banco Room local para tarefas/memórias/histórico, reconhecimento de fala Android (pt-BR), síntese de voz Android e cliente HTTP para backend de IA. O app não contém chaves de provedor.

## Requisitos
- Android Studio recente, JDK 17 e Android SDK Platform 35.
- Gradle 8.9 ou compatível com Android Gradle Plugin 8.7.3.
- Android 8.0 (API 26) ou superior. Teste em aparelho real; reconhecimento de fala depende dos serviços instalados no dispositivo.

## Abrir e compilar
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute `:app:assembleDebug` ou `gradle assembleDebug`.
4. APK Debug: `app/build/outputs/apk/debug/app-debug.apk`.
5. O workflow `.github/workflows/android.yml` compila e publica o APK como artefato na aba Actions.

> Este pacote não inclui o Gradle Wrapper. O Android Studio pode configurar o Gradle localmente; no CI o workflow usa Gradle instalado pela action.

## IA real: contrato do backend
Na tela Configurações, informe uma URL **HTTPS** de backend que aceite `POST` JSON:

```json
{
  "messages": [
    {"role":"system","content":"..."},
    {"role":"user","content":"Olá"}
  ]
}
```

Resposta esperada:

```json
{"reply":"Olá. Como posso ajudar?"}
```

O backend deve autenticar o app conforme sua estratégia, validar limites e encaminhar a solicitação ao provedor escolhido. Guarde a chave do provedor apenas no servidor (secret/environment variable), nunca no APK. O cliente Android deliberadamente não inclui um backend hospedado nem uma chave de IA. Sem URL configurada, o app informa que a IA não está configurada em vez de fingir uma resposta.

## Recursos e estado de implementação

### Implementado nesta base
- Interface escura futurista e navegação por Início, Conversa, Tarefas, Memória e Configurações.
- Núcleo animado leve na tela inicial.
- Conversa digitada com contexto recente enviado ao backend configurado.
- Reconhecimento de fala Android em pt-BR por botão, com permissão explícita.
- TTS do Android em pt-BR, com opção de desativar fala e botão para interromper.
- Room: tarefas, memórias explícitas e histórico local de mensagens.
- CRUD básico de tarefas (criar, concluir e excluir) e memórias (criar/excluir).
- Notificação local via receiver e agendador de alarme como base técnica; ainda não ligada ao formulário de tarefas nesta versão.
- Workflow de CI para compilar, testar e publicar APK Debug.

### Ainda precisa ser desenvolvido/configurado
- Agenda com calendário, datas e edição completa; agendamento integrado à tela e restauração de alarmes após reinicialização.
- Backend real de IA: implantação, autenticação, limites, seleção de modelos, streaming e tratamento detalhado do provedor.
- Ações por linguagem natural com confirmação e executor de ferramentas (não executa automaticamente comandos interpretados pelo modelo).
- Integração oficial do YouTube: projeto Google Cloud, OAuth 2.0, YouTube Data API e YouTube Analytics API; ainda não há canal conectado nem métricas reais.
- Projetos de desenvolvimento, exportação de dados, tela de privacidade completa, seleção avançada de vozes e ativação por palavra-chave.
- Testes instrumentados, teste de build no ambiente alvo e auditoria de segurança.

## Privacidade
Tarefas, memórias e histórico são armazenados no banco local do app. Quando configurado, o texto da conversa é enviado pela internet ao endpoint HTTPS definido pelo usuário, que poderá encaminhá-lo a um provedor externo. Não inclua senhas ou segredos em mensagens. Apagar o histórico na tela Conversa remove os registros locais; isso não apaga logs que um backend ou provedor possa ter mantido.

## Limitações importantes
Este é um projeto inicial funcional para continuar evoluindo, não uma implementação final de todos os módulos do escopo. Não existe escuta permanente de microfone. O app não alega ter conectado YouTube, acessado calendário externo ou executado ações fora do app. Confirme permissões e política de notificações no Android.
